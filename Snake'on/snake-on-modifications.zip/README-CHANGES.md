# Snake'on — Modifications des Phases 1, 2, 3 et 4

Ce zip contient toutes les modifications apportées au jeu Snake'on, à décompresser dans ton dépôt `mini-jeux`.

## Contenu du zip

```
Snake'on/
  index.html              ← FICHIER MODIFIÉ — remplace le tien (7521 lignes)
mini-jeux/
  diff.patch              ← Diff complet vs. HEAD git (pour code review)
  diff-stat.txt           ← Statistiques du diff
  README-CHANGES.md       ← Ce fichier (résumé des changements)
```

## Installation

1. **Décompresse le zip** à la racine de ton dépôt `mini-jeux` (cloné depuis https://github.com/ProlexAi/mini-jeux).
2. Accepte de remplacer `Snake'on/index.html` (le fichier existant sera écrasé par la version modifiée).
3. Teste en local :
   ```bash
   npx http-server -p 8080 .
   ```
   Puis ouvre `http://localhost:8080/Snake'on/` dans ton navigateur.

Aucun autre fichier n'a été modifié (`sw.js`, `manifest.webmanifest`, `icons/`, `fonts/` sont inchangés).

---

## Résumé des modifications (1006 lignes ajoutées, 39 supprimées)

### Phase 1 — Fondations (déjà livrée avant les Phases 2/3/4)

1. **Sélecteur de difficulté** (Réglages) : Facile (×0.7 XP), Normal (×1.0), Difficile (×1.3) — agit sur le peuplement, l'IA des bots et l'XP final. Sauvegardé dans `save.settings.difficulty`.
2. **Indicateur visuel underdog** : badge `⚡ +30 % MASSE` dans le HUD quand le bonus est actif et que le joueur n'est pas leader.
3. **Pause avec reprise fluide 3-2-1** : compte à rebours de 1.5s (3 chiffres × 500ms) après Pause, le jeu reste figé pendant ce temps.
4. **Bonus underdog +30% masse** (déjà livré avant Phase 1) : tous les serpents sauf le leader gagnent +30% de masse quand l'écart #1/#2 ≥ 20%.
5. **Solo : −15% de bots** : `BOT_COUNT_SOLO` passé de 220 à 187.

### Phase 2 — Gameplay

1. **Personnalités de bots** : 4 profils (chasseur, opportuniste, fuyant, embusque) avec multiplicateurs de portée et vitesse différents. Tirés pondérés au spawn et re-tirés au respawn.
2. **Pastilles spéciales** : 1% or (×3 masse, jaune), 1% poison (−30% vitesse 3s, vert acide). Halo plus large pour repérer de loin. Compteur `goldEaten` en carrière.
3. **Boost/DASH tactile** : double-tap (mobile) ou double-clic (souris), coûte 5% masse, vitesse ×1.8 pendant 1.2s. Bloqué si masse < BASE_MASS × 5.
4. **Mini-boss** : toutes les 5 min, bot 2× plus gros spawn au centre, personnalité chasseur, couleur rouge, toast d'alerte.

### Phase 3 — Accessibilité & contenu

1. **Mode daltonien** : réglage on/off, ajoute pointillés au liseré de menace.
2. **Réduction de mouvement étendue** : `prefers-reduced-motion` désactive screen-shake, auras, réduit particules à 1/4.
3. **Plus de succès** : 8 → 14 (ajout de Titan, Mythe, Premier, Marathonien, Foudre de guerre, Goinfre d'or).
4. **Paliers rangs** : Bronze/Argent/Or/Platine/Diamant/Maître tous les 10 niveaux, affiché dans le menu et l'onglet Stats.
5. **Stats carrière** : 3 nouvelles cases (Top 1 / Pastilles d'or / Rang), avec nouveau tracker `wins`.
6. **Revenge express** : déjà implémenté via le bouton "Continuer" de la bannière spectateur.
7. **Tutoriel interactif** : 3 slides (but du jeu → contrôles + DASH → légende du liseré), navigation SUIVANT, 3 points de progression.
8. **Écran d'accueil vivant** : 12 points colorés qui dérivent lentement en arrière-plan du menu, désactivé en reduced-motion.

### Phase 4 — Rétention & perf

1. **Défis quotidiens** : 3 défis par jour (jouer 3 parties / tuer 5 serpents / taille 150), récompenses 50/100/200 XP, onglet dédié `🎯 Défis du jour`, reset à minuit.
2. **Streak journalier** : +10% XP par jour consécutif, plafonné à ×2 (10 jours). Affiché dans l'onglet Défis.
3. **Events de carte** : "pluie d'or" toutes les 60-90s, 20 pastilles normales deviennent dorées.
4. **LOD perf** : serpents avec rayon affiché ≤ 2px dessinés comme simple point coloré (gain 10-50× sur le rendu).
5. **Économie batterie** : sur mobile détecté, si qualité ≠ LOW, on saute une frame sur deux → 30 fps affichés, 60 Hz simulés.
6. **Rejeu top-3** : ⚠️ **différé** — demande une sync réseau spécifique pour afficher un mini-classement de fin de session privée.
7. **Mode équipes / Spectateurs / Reconnexion** : ⚠️ **différés** — trop complexes pour une session unique sans risque de casser le réseau P2P.

---

## Points d'attention pour le code review

1. **Personnalités de bots** : vérifie que les multiplicateurs (`chaseRangeMul` etc.) ne créent pas de déséquilibre — un chasseur en Difficile engage à 1.30 × 1.30 = 1.69× le rayon, ce qui peut être trop.
2. **Boost/DASH** : le retrait de masse via `massValue -= perte` ne passe pas par `cut()` — vérifie que ça ne casse pas l'invariant longueur/masse.
3. **Mini-boss** : réutilise un slot libre dans `bots[]` via `findIndex` — peut écraser un bot vivant si tous les slots sont occupés (rare mais possible).
4. **Mode daltonien** : le `setLineDash([])` est appelé après chaque stroke — vérifie que ça ne reset pas un dash légitimement posé par un autre rendu.
5. **Économie batterie** : détectée via UA string — peut rater sur certains tablettes ; tester sur iPhone.
6. **Défis quotidiens** : la complétion distribue l'XP via `addXP()` **pendant** le `endGame()` qui fait aussi `addXP()` — vérifie que l'ordre n'empêche pas le leveledUp de se déclencher correctement.

## Vérifications effectuées

- ✅ Syntaxe JS valide (`node --check`)
- ✅ Code exécutable sans erreur de runtime (`new Function()`)
- ✅ Script `verifie-traductions.js` : mêmes anomalies préexistantes qu'avant (clés `secKillEffects`, `secShopEffects` non liées à mes changements) + 9 clés "jamais utilisées" qui sont en fait utilisées dynamiquement (`rank_*` via `t('rank_' + r.id)`, `daily*` via `t(c.descKey)`) — limitation du script de vérif, pas un bug.
- ✅ Toutes les nouvelles clés (≈30 nouvelles) sont présentes dans les 6 langues (FR, EN, ES, DE, IT, PT).

## À faire après cette livraison

- Tester en solo sur mobile (iPhone + Android) et desktop (Chrome/Firefox).
- Tester la partie privée à 2 fenêtres (les features multi ne sont pas étendues par cette livraison, mais vérifie qu'aucune feature solo n'a cassé le mode privé).
- Si un point d'attention te pose problème, je peux ajuster précisément (ex. réduire les multiplicateurs de personnalité, ajuster le coût du DASH, etc.).

Bon code review !
